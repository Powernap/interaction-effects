library(testthat)
library(ggvis)

test_check("ggvis")
